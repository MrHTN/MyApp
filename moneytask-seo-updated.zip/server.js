require('dotenv').config();
const express = require('express');
const path = require('path')
const mongoose = require('mongoose');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const { notFound, errorHandler } = require('./src/middleware');
const authRoutes = require('./src/routes/auth.routes');
const taskRoutes = require('./src/routes/tasks.routes');
const walletRoutes = require('./src/routes/wallet.routes');
const adminRoutes = require('./src/routes/admin.routes');
const publicRoutes = require('./src/routes/public.routes');
const { PORT = 4000, MONGO_URI, SESSION_SECRET, CLIENT_ORIGIN, COOKIE_SECURE } = process.env;

if (!MONGO_URI || !SESSION_SECRET) {
  console.error('MONGO_URI و SESSION_SECRET باید در .env تنظیم شوند');
  process.exit(1);
}

const app = express();

// فقط به یک لایه‌ی پراکسی (Nginx) اعتماد کن، نه به همه‌ی هدرها
app.set('trust proxy', 1);

// امنیت پایه + CORS محدود به فرانت‌اند (چون سشن از کوکی استفاده می‌کند، credentials لازم است)
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        // چون صفحات از CDN تیلویند و اسکریپت‌های inline استفاده می‌کنن، باید اجازه داده بشه
        scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdn.tailwindcss.com'],
        // helmet به‌صورت پیش‌فرض script-src-attr رو روی 'none' می‌ذاره که onclick/onsubmit/oninput
        // (که توی همه‌ی صفحات استفاده شده) رو بلاک می‌کنه؛ باید صریحاً اجازه بدیم
        scriptSrcAttr: ["'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      },
    },
  })
);
app.use(
  cors({
    origin: (CLIENT_ORIGIN || '').split(',').filter(Boolean),
    credentials: true,
  })
);
app.use(express.json({ limit: '100kb' }));
// index: false چون خودمان پایین‌تر روت «/» را دستی مدیریت می‌کنیم (چک سشن قبل از نمایش index.html)؛
// وگرنه express.static به‌صورت پیش‌فرض index.html را مستقیم و بدون چک سشن سرو می‌کرد
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// محدودسازی نرخ درخواست روی مسیرهای احراز هویت برای جلوگیری از brute-force
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, max: 30 }));

// سشن با ذخیره‌سازی روی MongoDB (پایدار در ری‌استارت سرور)
app.use(
  session({
    name: 'mt.sid',
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({ mongoUrl: MONGO_URI, ttl: 14 * 24 * 60 * 60 }),
    cookie: {
      httpOnly: true,
      secure: COOKIE_SECURE === 'true', // تا SSL نصب نکردی حتماً false بمونه، وگرنه کوکی اصلاً ذخیره نمی‌شه
      sameSite: 'lax',
      maxAge: 14 * 24 * 60 * 60 * 1000, // ۱۴ روز
    },
  })
);

// دامنه‌ی خالی: اگه سشن معتبر داره مستقیم بره داشبورد (یا پنل ادمین)، وگرنه صفحه فرود عمومی (index.html)
// را نشان بده تا هم گوگل چیزی برای ایندکس پیدا کند و هم بازدیدکننده‌ی بدون حساب محتوای واقعی ببیند
app.get('/', (req, res) => {
  if (req.session && req.session.userId) {
    return res.redirect(req.session.role === 'admin' ? '/admin-dashboard.html' : '/dashboard.html');
  }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// robots.txt — فقط صفحات عمومی و بدون نیاز به لاگین اجازه ایندکس دارند؛
// صفحات داشبورد/تسک/پروفایل/ادمین چون بدون احراز هویت محتوای واقعی ندارند (خالی/خطا هستند)
// و همه API ها هم داده‌ی کاربر خاص هستند، از خزش گوگل خارج می‌شوند تا crawl budget هدر نرود.
app.get('/robots.txt', (req, res) => {
  res.type('text/plain');
  res.send(
    [
      'User-agent: *',
      'Allow: /$',
      'Allow: /login.html',
      'Allow: /support.html',
      'Disallow: /api/',
      'Disallow: /dashboard.html',
      'Disallow: /tasks.html',
      'Disallow: /task-details.html',
      'Disallow: /profile.html',
      'Disallow: /forgot-password.html',
      'Disallow: /reset-password.html',
      'Disallow: /admin-login.html',
      'Disallow: /admin-dashboard.html',
      'Disallow: /uploads/',
      `Sitemap: ${(CLIENT_ORIGIN || '').split(',')[0] || ''}/sitemap.xml`,
    ].join('\n')
  );
});

// sitemap.xml — صفحه فرود (/) به‌عنوان صفحه اصلی سایت در بالای لیست
app.get('/sitemap.xml', (req, res) => {
  const origin = (CLIENT_ORIGIN || '').split(',')[0] || '';
  res.type('application/xml');
  res.send(
    `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n<url><loc>${origin}/</loc></url>\n<url><loc>${origin}/login.html</loc></url>\n<url><loc>${origin}/support.html</loc></url>\n</urlset>`
  );
});

// روت‌ها — مطابق صفحات فرانت‌اند
app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/users/me', walletRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/public', publicRoutes);

app.get('/api/health', (req, res) => res.json({ ok: true }));

app.use(notFound);
app.use(errorHandler);

mongoose
  .connect(MONGO_URI)
  .then(() => {
    app.listen(PORT, () => console.log('concted ok'));
  })
  .catch((err) => {
    console.error('❌ اتصال به MongoDB ناموفق بود:', err.message);
    process.exit(1);
  });
