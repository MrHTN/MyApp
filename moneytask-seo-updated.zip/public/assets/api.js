/**
 * تنظیمات و توابع مشترک اتصال به بک‌اند — در همه صفحات لود می‌شود.
 * برای پروداکشن فقط کافیست API_BASE را به آدرس واقعی بک‌اند تغییر دهید.
 */
const API_BASE = '/api';

/**
 * fetch سراسری با ارسال کوکی سشن و پارس خودکار JSON
 */
async function apiFetch(path, options = {}) {
  const res = await fetch(API_BASE + path, {
    credentials: 'include', // برای ارسال کوکی سشن (express-session)
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options,
  });
  let data = null;
  try {
    data = await res.json();
  } catch (_) {
    /* بدنه خالی یا غیر JSON */
  }
  if (!res.ok) {
    throw new Error((data && data.message) || 'خطایی رخ داد، لطفاً دوباره تلاش کنید');
  }
  return data;
}

/** برای صفحات کاربر عادی: اگر لاگین نیست به login.html بفرست */
async function requireAuthOrRedirect() {
  try {
    const data = await apiFetch('/auth/me');
    return data.user;
  } catch (_) {
    window.location.href = 'login.html';
    return null;
  }
}

/** برای صفحات ادمین: اگر لاگین نیست یا نقش ادمین ندارد به admin-login.html بفرست */
async function requireAdminOrRedirect() {
  try {
    const data = await apiFetch('/auth/me');
    if (data.user.role !== 'admin') {
      window.location.href = 'admin-login.html';
      return null;
    }
    return data.user;
  } catch (_) {
    window.location.href = 'admin-login.html';
    return null;
  }
}

/** خروج از حساب و بازگشت به صفحه لاگین مناسب */
async function logout(redirectTo = 'login.html') {
  try {
    await apiFetch('/auth/logout', { method: 'POST' });
  } finally {
    window.location.href = redirectTo;
  }
}

/**
 * آپلود فایل (multipart/form-data) — عمداً هدر Content-Type ست نمی‌شود چون خود مرورگر
 * باید boundary فرم را اضافه کند؛ برای مواردی مثل آپلود اسکرین‌شات اثبات انجام تسک
 */
async function apiUpload(path, formData) {
  const res = await fetch(API_BASE + path, {
    method: 'POST',
    credentials: 'include',
    body: formData,
  });
  let data = null;
  try {
    data = await res.json();
  } catch (_) {
    /* بدنه خالی یا غیر JSON */
  }
  if (!res.ok) {
    throw new Error((data && data.message) || 'خطایی رخ داد، لطفاً دوباره تلاش کنید');
  }
  return data;
}

/** فرمت عدد به تومان با اعداد فارسی */
function formatToman(n) {
  return Number(n || 0).toLocaleString('fa-IR');
}

/** فرمت تاریخ + ساعت با اعداد فارسی، مثلاً ۱۴۰۳/۴/۲۹ - ۱۴:۳۰ */
function formatDateTime(iso) {
  const d = new Date(iso);
  const date = d.toLocaleDateString('fa-IR');
  const time = d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
  return `${date} - ${time}`;
}

/** نمایش/مخفی‌کردن پیام خطا در یک عنصر مشخص */
function showError(elId, message) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.textContent = message;
  el.classList.remove('hidden');
}
function hideError(elId) {
  const el = document.getElementById(elId);
  if (el) el.classList.add('hidden');
}
