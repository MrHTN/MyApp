const router = require('express').Router();
const fs = require('fs');
const path = require('path');
const { Task, Submission, Category } = require('../models');
const { asyncHandler, requireAuth, validateBody, submitLimiter } = require('../middleware');
const { handleProofUpload, uploadDir } = require('../middleware/upload');

// کارمزد سیستم از بودجه‌ی تسک‌های ثبت‌شده توسط کاربر + حداقل سهم مجاز هر نفر
const SYSTEM_FEE_RATE = 0.3;
const MIN_TASK_PRICE = 1000;

// جلوگیری از تزریق کاراکترهای خاص regex در پارامتر جست‌وجو
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// GET /api/tasks?category=طراحی&search=عنوان — طبق چیپ‌های فیلتر و جست‌وجوی عنوان در tasks.html
// فقط تسک‌های تاییدشده (چه ادمین ساخته باشد چه کاربر و توسط ادمین تایید شده باشد) نمایش داده می‌شود
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const filter = { isActive: true, status: 'approved' };
    if (req.query.category && req.query.category !== 'همه') filter.category = req.query.category;
    if (req.query.search && req.query.search.trim()) filter.title = new RegExp(escapeRegex(req.query.search.trim()), 'i');

    const tasks = await Task.find(filter).sort({ createdAt: -1 }).lean();
    res.json({ ok: true, tasks });
  })
);

// GET /api/tasks/requests/mine — درخواست‌های تسکِ ثبت‌شده توسط خود کاربر (برای پیگیری وضعیت)
router.get(
  '/requests/mine',
  requireAuth,
  asyncHandler(async (req, res) => {
    const tasks = await Task.find({ createdBy: req.session.userId }).sort({ createdAt: -1 }).lean();
    res.json({ ok: true, tasks });
  })
);

// POST /api/tasks/requests — ثبت تسک جدید توسط کاربر عادی با بودجه‌ی کیف‌پول؛ می‌رود در صف تایید ادمین
// نکته امنیتی: بودجه در همین لحظه از کیف‌پول کم نمی‌شود؛ فقط در لحظه‌ی تایید ادمین کسر می‌شود
router.post(
  '/requests',
  requireAuth,
  validateBody({ title: 'string', category: 'string', budget: 'number', requiredCount: 'number' }),
  asyncHandler(async (req, res) => {
    const { title, category, description, budget, requiredCount } = req.body;

    if (budget <= 0) {
      return res.status(400).json({ ok: false, message: 'بودجه باید بزرگ‌تر از صفر باشد' });
    }
    if (!Number.isInteger(requiredCount) || requiredCount < 1) {
      return res.status(400).json({ ok: false, message: 'تعداد مورد نیاز نامعتبر است' });
    }

    // ۷۰٪ بودجه بین requiredCount نفر تقسیم می‌شود؛ رند به‌سمت پایین تا مجموع پرداختی هیچ‌وقت از ۷۰٪ بیشتر نشود
    const price = Math.floor((budget * (1 - SYSTEM_FEE_RATE)) / requiredCount);
    if (price < MIN_TASK_PRICE) {
      return res.status(400).json({
        ok: false,
        message: `بودجه برای این تعداد نفر کافی نیست؛ سهم هر نفر باید حداقل ${MIN_TASK_PRICE.toLocaleString('fa-IR')} تومان باشد`,
      });
    }

    const task = await Task.create({
      title,
      category,
      description: description || '',
      budget,
      price,
      requiredCount,
      createdBy: req.session.userId,
      status: 'pending',
      isActive: false, // تا تایید ادمین در لیست عمومی تسک‌ها نمایش داده نمی‌شود
    });

    res.status(201).json({ ok: true, task });
  })
);

// GET /api/tasks/categories — لیست دسته‌بندی‌های فعال، برای منوی انتخاب دسته در ثبت/فیلتر تسک
router.get(
  '/categories',
  asyncHandler(async (req, res) => {
    const categories = await Category.find({ isActive: true }).sort({ name: 1 }).lean();
    res.json({ ok: true, categories });
  })
);

// GET /api/tasks/:id — طبق task-details.html (شامل پیشرفت ۶ / ۱۰)
router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const task = await Task.findById(req.params.id).lean();
    if (!task) return res.status(404).json({ ok: false, message: 'تسک یافت نشد' });

    const approvedCount = await Submission.countDocuments({ task: task._id, status: 'approved' });

    let mySubmission = null;
    if (req.session && req.session.userId) {
      const sub = await Submission.findOne({ task: task._id, user: req.session.userId }).sort({ createdAt: -1 }).select('status');
      if (sub) mySubmission = { id: sub._id, status: sub.status };
    }

    res.json({ ok: true, task: { ...task, approvedCount, mySubmission } });
  })
);

// POST /api/tasks/:id/submit — دکمه «انجام تسک»؛ یک submission با وضعیت pending می‌سازد
// آپلود اسکرین‌شات اثبات انجام تسک (فیلد proof) اجباری است — حداکثر ۵ مگابایت
router.post(
  '/:id/submit',
  requireAuth,
  submitLimiter,
  handleProofUpload,
  asyncHandler(async (req, res) => {
    if (!req.file) {
      return res.status(400).json({ ok: false, message: 'آپلود اسکرین‌شات اثبات انجام تسک الزامی است' });
    }

    const cleanupUploadedFile = () => fs.unlink(path.join(uploadDir, req.file.filename), () => {});

    const task = await Task.findById(req.params.id);
    if (!task || !task.isActive || task.status !== 'approved') {
      cleanupUploadedFile();
      return res.status(404).json({ ok: false, message: 'تسک یافت نشد' });
    }
    if (task.expiresAt && task.expiresAt < new Date()) {
      cleanupUploadedFile();
      return res.status(400).json({ ok: false, message: 'مهلت این تسک به پایان رسیده است' });
    }

    const approvedCount = await Submission.countDocuments({ task: task._id, status: 'approved' });
    if (approvedCount >= task.requiredCount) {
      cleanupUploadedFile();
      return res.status(400).json({ ok: false, message: 'ظرفیت این تسک تکمیل شده است' });
    }

    try {
      const submission = await Submission.create({
        task: task._id,
        user: req.session.userId,
        proofImage: `/uploads/${req.file.filename}`,
      });
      res.status(201).json({ ok: true, submission });
    } catch (err) {
      cleanupUploadedFile();
      if (err.code === 11000) {
        return res.status(409).json({ ok: false, message: 'شما قبلاً این تسک را ثبت کرده‌اید' });
      }
      throw err;
    }
  })
);

// DELETE /api/tasks/submissions/:id — لغو انجام‌تسک ثبت‌شده توسط خود کاربر، فقط تا وقتی وضعیتش «در انتظار» است
router.delete(
  '/submissions/:id',
  requireAuth,
  asyncHandler(async (req, res) => {
    const submission = await Submission.findById(req.params.id);
    if (!submission || submission.user.toString() !== req.session.userId) {
      return res.status(404).json({ ok: false, message: 'رکورد یافت نشد' });
    }
    if (submission.status !== 'pending') {
      return res.status(400).json({ ok: false, message: 'این مورد قبلاً بررسی شده و دیگر قابل لغو نیست' });
    }
    const proofPath = path.join(uploadDir, path.basename(submission.proofImage));
    await submission.deleteOne();
    fs.unlink(proofPath, () => {});
    res.json({ ok: true });
  })
);

module.exports = router;
