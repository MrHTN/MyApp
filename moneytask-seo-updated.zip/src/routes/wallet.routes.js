const router = require('express').Router();
const { User, Submission, Transaction } = require('../models');
const { asyncHandler, requireAuth, validateBody, transactionLimiter } = require('../middleware');

router.use(requireAuth);

// GET /api/users/me/dashboard — طبق dashboard-1.html (موجودی، آمار تسک‌ها، تسک‌های اخیر)
router.get(
  '/dashboard',
  asyncHandler(async (req, res) => {
    const userId = req.session.userId;
    const [user, inProgress, completed, recent] = await Promise.all([
      User.findById(userId).lean(),
      Submission.countDocuments({ user: userId, status: 'pending' }),
      Submission.find({ user: userId, status: 'approved' }).populate('task', 'price'),
      Submission.find({ user: userId }).sort({ createdAt: -1 }).limit(5).populate('task', 'title price category'),
    ]);

    const totalIncome = completed.reduce((sum, s) => sum + (s.task?.price || 0), 0);

    res.json({
      ok: true,
      walletBalance: user.walletBalance,
      stats: { inProgress, completed: completed.length, totalIncome },
      recentTasks: recent.map((s) => ({
        id: s._id,
        title: s.task?.title,
        category: s.task?.category,
        price: s.task?.price,
        status: s.status,
      })),
    });
  })
);

// GET /api/users/me/profile — طبق profile.html
router.get(
  '/profile',
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.session.userId).lean();
    const transactions = await Transaction.find({ user: req.session.userId }).sort({ createdAt: -1 }).limit(10);
    res.json({
      ok: true,
      user: {
        id: user._id,
        fullname: user.fullname,
        username: user.username,
        email: user.email,
        phone: user.phone,
        cardNumber: user.cardNumber,
        walletBalance: user.walletBalance,
        createdAt: user.createdAt,
      },
      transactions,
    });
  })
);

// GET /api/users/me/transactions — لیست کامل تراکنش‌ها
router.get(
  '/transactions',
  asyncHandler(async (req, res) => {
    const transactions = await Transaction.find({ user: req.session.userId }).sort({ createdAt: -1 });
    res.json({ ok: true, transactions });
  })
);

// POST /api/users/me/transactions — دکمه «برداشت وجه» / «افزایش موجودی» در profile.html
// نکته مهم امنیتی: موجودی فقط پس از تایید ادمین تغییر می‌کند (نه در همین لحظه)
router.post(
  '/transactions',
  transactionLimiter,
  validateBody({ type: 'string', amount: 'number' }),
  asyncHandler(async (req, res) => {
    const { type, amount, cardNumber, depositorName, depositTime } = req.body;
    if (!['deposit', 'withdraw'].includes(type)) {
      return res.status(400).json({ ok: false, message: 'نوع تراکنش نامعتبر است' });
    }
    if (amount <= 0) {
      return res.status(400).json({ ok: false, message: 'مبلغ باید بزرگ‌تر از صفر باشد' });
    }

    const payload = { user: req.session.userId, type, amount };

    if (type === 'withdraw') {
      if (!cardNumber || typeof cardNumber !== 'string' || !cardNumber.trim()) {
        return res.status(400).json({ ok: false, message: 'شماره کارت الزامی است' });
      }
      const user = await User.findById(req.session.userId);
      if (user.walletBalance < amount) {
        return res.status(400).json({ ok: false, message: 'موجودی کیف پول کافی نیست' });
      }
      payload.cardNumber = cardNumber.trim();
    } else {
      if (!depositorName || typeof depositorName !== 'string' || !depositorName.trim()) {
        return res.status(400).json({ ok: false, message: 'نام و نام خانوادگی واریزکننده الزامی است' });
      }
      if (!depositTime || typeof depositTime !== 'string' || !depositTime.trim()) {
        return res.status(400).json({ ok: false, message: 'زمان واریز الزامی است' });
      }
      payload.depositorName = depositorName.trim();
      payload.depositTime = depositTime.trim();
    }

    const transaction = await Transaction.create(payload);
    res.status(201).json({ ok: true, transaction });
  })
);

// PATCH /api/users/me/profile — ویرایش نام، شماره تماس و شماره کارت توسط خود کاربر
router.patch(
  '/profile',
  asyncHandler(async (req, res) => {
    const allowed = ['fullname', 'phone', 'cardNumber'];
    const updates = {};
    for (const key of allowed) if (req.body[key] !== undefined) updates[key] = req.body[key];

    const user = await User.findByIdAndUpdate(req.session.userId, updates, { new: true, runValidators: true }).select('-passwordHash');
    if (!user) return res.status(404).json({ ok: false, message: 'کاربر یافت نشد' });
    res.json({
      ok: true,
      user: {
        id: user._id,
        fullname: user.fullname,
        username: user.username,
        email: user.email,
        phone: user.phone,
        cardNumber: user.cardNumber,
        walletBalance: user.walletBalance,
      },
    });
  })
);

module.exports = router;
