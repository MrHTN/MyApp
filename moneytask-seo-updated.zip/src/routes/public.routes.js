const router = require('express').Router();
const { User, Task, Submission } = require('../models');
const { asyncHandler } = require('../middleware');

/**
 * آمار عمومی صفحه فرود (index.html) — کاملاً بدون نیاز به لاگین.
 * عمداً یک روت مستقل است (نه بخشی از tasks.routes یا admin.routes) چون داده‌اش از چند
 * مدل مختلف (User + Submission) می‌آید و مسئولیتش صرفاً «نمایش اعتمادسازی عمومی» است،
 * نه مدیریت تسک یا کاربر؛ اگر بعداً فیلد آماری دیگری لازم شد فقط همین فایل تغییر می‌کند.
 *
 * نکته امنیتی/حریم خصوصی: هیچ داده‌ی شناسایی‌شونده (نام، شماره حساب و ...) برنمی‌گردد،
 * فقط شمارش‌ها و مجموع‌های تجمیعی.
 */
router.get(
  '/stats',
  asyncHandler(async (req, res) => {
    const [usersCount, completedTasksCount, activeTasksCount, payoutAgg, budgetAgg] = await Promise.all([
      User.countDocuments({ role: 'user' }),
      Submission.countDocuments({ status: 'approved' }),
      Task.countDocuments({ isActive: true, status: 'approved' }),
      Submission.aggregate([
        { $match: { status: 'approved' } },
        { $lookup: { from: 'tasks', localField: 'task', foreignField: '_id', as: 'task' } },
        { $unwind: '$task' },
        { $group: { _id: null, total: { $sum: '$task.price' } } },
      ]),
      // بودجه‌ی تسک‌هایی که کارفرماها ثبت کرده و ادمین تایید کرده (یعنی واقعاً از کیف‌پول کسر شده)
      Task.aggregate([
        { $match: { createdBy: { $ne: null }, status: 'approved' } },
        { $group: { _id: null, total: { $sum: '$budget' } } },
      ]),
    ]);

    res.json({
      ok: true,
      stats: {
        usersCount,
        completedTasksCount,
        activeTasksCount,
        totalPaidOut: payoutAgg[0]?.total || 0,
        totalBudgetAllocated: budgetAgg[0]?.total || 0,
      },
    });
  })
);

module.exports = router;
