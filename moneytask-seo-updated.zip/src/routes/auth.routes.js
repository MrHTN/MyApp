const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { User } = require('../models');
const crypto = require('crypto');
const { sendResetPasswordEmail } = require('../utils/mailer');
const { asyncHandler, validateBody, requireAuth, passwordResetLimiter } = require('../middleware');

const publicUser = (u) => ({
  id: u._id,
  fullname: u.fullname,
  username: u.username,
  email: u.email,
  role: u.role,
  walletBalance: u.walletBalance,
  status: u.status,
  createdAt: u.createdAt,
});

// POST /api/auth/signup — طبق formSignup در login.html
router.post(
  '/signup',
  validateBody({ fullname: 'string', username: 'string', password: 'string' }),
  asyncHandler(async (req, res) => {
    const { fullname, username, email, password } = req.body;
    if (password.length < 8) {
      return res.status(400).json({ ok: false, message: 'رمز عبور باید حداقل ۸ کاراکتر باشد' });
    }
    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({
      fullname,
      username: username.toLowerCase(),
      email: email || null,
      passwordHash,
    });

    req.session.userId = user._id.toString();
    req.session.role = user.role;
    user.currentSessionId = req.sessionID;
    await user.save();
    res.status(201).json({ ok: true, user: publicUser(user) });
  })
);

// POST /api/auth/login — طبق formLogin در login.html (ورود با username یا email)
router.post(
  '/login',
  validateBody({ username: 'string', password: 'string' }),
  asyncHandler(async (req, res) => {
    const { username, password } = req.body;
    const identifier = username.toLowerCase();
    const user = await User.findOne({ $or: [{ username: identifier }, { email: identifier }] });
    if (!user || user.status === 'blocked') {
      return res.status(401).json({ ok: false, message: 'نام کاربری یا رمز عبور اشتباه است' });
    }
    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ ok: false, message: 'نام کاربری یا رمز عبور اشتباه است' });
    }

    req.session.userId = user._id.toString();
    req.session.role = user.role;
    user.currentSessionId = req.sessionID;
    await user.save();
    res.json({ ok: true, user: publicUser(user) });
  })
);

// POST /api/auth/admin-login — طبق admin-login.html (فقط role=admin اجازه ورود دارد)
router.post(
  '/admin-login',
  validateBody({ username: 'string', password: 'string' }),
  asyncHandler(async (req, res) => {
    const { username, password } = req.body;
    const user = await User.findOne({ username: username.toLowerCase(), role: 'admin' });
    if (!user || user.status === 'blocked') {
      return res.status(401).json({ ok: false, message: 'نام کاربری یا رمز عبور اشتباه است' });
    }
    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ ok: false, message: 'نام کاربری یا رمز عبور اشتباه است' });
    }

    req.session.userId = user._id.toString();
    req.session.role = user.role;
    user.currentSessionId = req.sessionID;
    await user.save();
    res.json({ ok: true, user: publicUser(user) });
  })
);

// POST /api/auth/logout — طبق لینک «خروج از حساب» در profile.html و admin-dashboard.html
router.post(
  '/logout',
  asyncHandler(async (req, res) => {
    const userId = req.session.userId;
    if (userId) {
      await User.updateOne({ _id: userId }, { currentSessionId: null }).catch(() => {});
    }
    req.session.destroy(() => {
      res.clearCookie('mt.sid');
      res.json({ ok: true });
    });
  })
);

// GET /api/auth/me — برای اینکه فرانت‌اند وضعیت لاگین را چک کند
router.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.session.userId);
    if (!user) return res.status(401).json({ ok: false, message: 'نشست نامعتبر است' });
    res.json({ ok: true, user: publicUser(user) });
  })
);

// POST /api/auth/forgot-password — طبق forgot-password.html
// همیشه پیام یکسان برمی‌گرداند (چه کاربر/ایمیل وجود داشته باشد چه نه) تا شمارش کاربران ممکن نباشد
router.post(
  '/forgot-password',
  passwordResetLimiter,
  validateBody({ username: 'string' }),
  asyncHandler(async (req, res) => {
    const identifier = req.body.username.trim().toLowerCase();
    const genericMessage = 'اگر حسابی با این مشخصات و یک ایمیل ثبت‌شده وجود داشته باشد، لینک بازیابی رمز عبور برایش ارسال می‌شود.';

    const user = await User.findOne({ $or: [{ username: identifier }, { email: identifier }] });
    if (user && user.email) {
      const rawToken = crypto.randomBytes(32).toString('hex');
      user.resetPasswordTokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
      user.resetPasswordExpires = new Date(Date.now() + 30 * 60 * 1000); // ۳۰ دقیقه اعتبار
      await user.save();

      const base = process.env.CLIENT_ORIGIN || `${req.protocol}://${req.get('host')}`;
      const resetUrl = `${base}/reset-password.html?token=${rawToken}`;
      sendResetPasswordEmail(user.email, resetUrl).catch((err) => console.error('خطا در ارسال ایمیل بازیابی:', err.message));
    }

    res.json({ ok: true, message: genericMessage });
  })
);

// POST /api/auth/reset-password — طبق reset-password.html
router.post(
  '/reset-password',
  validateBody({ token: 'string', password: 'string' }),
  asyncHandler(async (req, res) => {
    const { token, password } = req.body;
    if (password.length < 8) {
      return res.status(400).json({ ok: false, message: 'رمز عبور باید حداقل ۸ کاراکتر باشد' });
    }
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    const user = await User.findOne({
      resetPasswordTokenHash: tokenHash,
      resetPasswordExpires: { $gt: new Date() },
    }).select('+resetPasswordTokenHash +resetPasswordExpires');

    if (!user) {
      return res.status(400).json({ ok: false, message: 'لینک بازیابی نامعتبر یا منقضی شده است' });
    }

    user.passwordHash = await bcrypt.hash(password, 10);
    user.resetPasswordTokenHash = null;
    user.resetPasswordExpires = null;
    user.currentSessionId = null; // خروج اجباری از سشن‌های قبلی برای امنیت بیشتر
    await user.save();

    res.json({ ok: true });
  })
);

module.exports = router;
