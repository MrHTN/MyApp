const router = require('express').Router();
const { User, Task, Transaction, Submission, Category } = require('../models');
const { asyncHandler, requireAuth, requireAdmin, validateBody } = require('../middleware');

router.use(requireAuth, requireAdmin);

/**
 * قطع یک سشن با sid مشخص از طریق sessionStore — با callback (طبق قرارداد استاندارد
 * express-session Store#destroy) تا وابسته به این نباشیم که پیاده‌سازی store بدون
 * callback هم Promise برگردونه یا نه.
 */
function destroySession(req, sid) {
  return new Promise((resolve) => {
    req.sessionStore.destroy(sid, () => resolve());
  });
}

// GET /api/admin/stats — کارت‌های بالای پنل ادمین
router.get(
  '/stats',
  asyncHandler(async (req, res) => {
    const [usersCount, tasksCount, pendingTx, volumeAgg, pendingTaskRequests, revenueAgg] = await Promise.all([
      User.countDocuments(),
      Task.countDocuments(),
      Transaction.countDocuments({ status: 'pending' }),
      Transaction.aggregate([{ $group: { _id: null, total: { $sum: '$amount' } } }]),
      Task.countDocuments({ createdBy: { $ne: null }, status: 'pending' }),
      Task.aggregate([
        { $match: { createdBy: { $ne: null }, status: 'approved' } },
        { $group: { _id: null, total: { $sum: { $subtract: ['$budget', { $multiply: ['$price', '$requiredCount'] }] } } } },
      ]),
    ]);
    res.json({
      ok: true,
      stats: {
        usersCount,
        tasksCount,
        pendingTransactions: pendingTx,
        totalVolume: volumeAgg[0]?.total || 0,
        pendingTaskRequests,
        systemRevenue: revenueAgg[0]?.total || 0,
      },
    });
  })
);

/**
 * پارامترهای صفحه‌بندی مشترک برای لیست‌های ادمین: ?page=&limit=
 */
function getPagination(req, defaultLimit = 20) {
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || defaultLimit, 1), 100);
  return { page, limit, skip: (page - 1) * limit };
}

// GET /api/admin/users?search=1024 — طبق userSearch در admin-dashboard.html
router.get(
  '/users',
  asyncHandler(async (req, res) => {
    const { search } = req.query;
    const filter = search ? { username: new RegExp(search, 'i') } : {};
    const { page, limit, skip } = getPagination(req);
    const [users, total] = await Promise.all([
      User.find(filter).select('-passwordHash').sort({ createdAt: -1 }).skip(skip).limit(limit),
      User.countDocuments(filter),
    ]);
    res.json({ ok: true, users, page, totalPages: Math.max(Math.ceil(total / limit), 1), total });
  })
);

// GET /api/admin/submissions?status=pending — لیست انجام‌تسک‌های کاربران برای بررسی ادمین
router.get(
  '/submissions',
  asyncHandler(async (req, res) => {
    const { status } = req.query;
    const filter = status && ['pending', 'approved', 'rejected'].includes(status) ? { status } : {};
    const { page, limit, skip } = getPagination(req);
    const [submissions, total] = await Promise.all([
      Submission.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .populate('user', 'fullname username')
        .populate('task', 'title price'),
      Submission.countDocuments(filter),
    ]);
    res.json({ ok: true, submissions, page, totalPages: Math.max(Math.ceil(total / limit), 1), total });
  })
);

// PATCH /api/admin/users/:id — ویرایش نقش/وضعیت/موجودی کاربر
router.patch(
  '/users/:id',
  asyncHandler(async (req, res) => {
    const allowed = ['fullname', 'role', 'status', 'walletBalance'];
    const updates = {};
    for (const key of allowed) if (req.body[key] !== undefined) updates[key] = req.body[key];

    const user = await User.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true }).select('-passwordHash');
    if (!user) return res.status(404).json({ ok: false, message: 'کاربر یافت نشد' });
    res.json({ ok: true, user });
  })
);

// DELETE /api/admin/users/:id — حذف کامل حساب کاربری
// نکته مهم: فقط کاربر عادی حذف می‌شود (نه ادمین دیگر). انجام‌تسک‌های کاربر (Submission) هم حذف می‌شوند،
// اما تراکنش‌های مالی (Transaction) برای حفظ سابقه‌ی مالی دست‌نخورده باقی می‌مانند
// (در نمایش آن‌ها به ادمین، کاربر حذف‌شده به‌صورت «کاربر حذف‌شده» نمایش داده می‌شود).
router.delete(
  '/users/:id',
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id).select('+currentSessionId');
    if (!user) return res.status(404).json({ ok: false, message: 'کاربر یافت نشد' });
    if (user.role === 'admin') {
      return res.status(403).json({ ok: false, message: 'امکان حذف حساب ادمین وجود ندارد' });
    }

    if (user.currentSessionId) {
      await destroySession(req, user.currentSessionId);
    }
    await Submission.deleteMany({ user: user._id });
    await user.deleteOne();

    res.json({ ok: true });
  })
);

// POST /api/admin/users/:id/logout — قطع اجباری سشن فعال کاربر (بدون حذف حساب)
router.post(
  '/users/:id/logout',
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id).select('+currentSessionId');
    if (!user) return res.status(404).json({ ok: false, message: 'کاربر یافت نشد' });

    if (user.currentSessionId) {
      await destroySession(req, user.currentSessionId);
      user.currentSessionId = null;
      await user.save();
    }
    res.json({ ok: true });
  })
);

// POST /api/admin/users/:id/wallet-adjustment — افزودن/کسر دستی موجودی توسط ادمین
// برخلاف تراکنش‌های عادی که با تایید ادمین از حالت pending خارج می‌شوند، این یک تراکنش
// از قبل تایید‌شده می‌سازد تا هم موجودی فوراً تغییر کند و هم در تب تراکنش‌ها قابل ردیابی باشد
router.post(
  '/users/:id/wallet-adjustment',
  validateBody({ type: 'string', amount: 'number' }),
  asyncHandler(async (req, res) => {
    const { type, amount, note } = req.body;
    if (!['add', 'subtract'].includes(type)) {
      return res.status(400).json({ ok: false, message: 'نوع تنظیم نامعتبر است' });
    }
    if (amount <= 0) {
      return res.status(400).json({ ok: false, message: 'مبلغ باید بزرگ‌تر از صفر باشد' });
    }

    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ ok: false, message: 'کاربر یافت نشد' });

    if (type === 'subtract') {
      if (user.walletBalance < amount) {
        return res.status(400).json({ ok: false, message: 'موجودی کاربر برای کسر این مبلغ کافی نیست' });
      }
      user.walletBalance -= amount;
    } else {
      user.walletBalance += amount;
    }
    await user.save();

    const transaction = await Transaction.create({
      user: user._id,
      type: type === 'add' ? 'deposit' : 'withdraw',
      amount,
      status: 'approved',
      note: note || (type === 'add' ? 'افزایش موجودی توسط ادمین' : 'کاهش موجودی توسط ادمین'),
    });

    res.json({ ok: true, walletBalance: user.walletBalance, transaction });
  })
);

/* ------------------------------ دسته‌بندی تسک‌ها ------------------------------ */

// GET /api/admin/categories
router.get(
  '/categories',
  asyncHandler(async (req, res) => {
    const categories = await Category.find().sort({ createdAt: -1 });
    res.json({ ok: true, categories });
  })
);

// POST /api/admin/categories — ساخت دسته‌بندی جدید
router.post(
  '/categories',
  validateBody({ name: 'string' }),
  asyncHandler(async (req, res) => {
    const name = req.body.name.trim();
    const exists = await Category.findOne({ name });
    if (exists) return res.status(400).json({ ok: false, message: 'این دسته‌بندی قبلا ثبت شده است' });
    const category = await Category.create({ name });
    res.status(201).json({ ok: true, category });
  })
);

// PATCH /api/admin/categories/:id — ویرایش نام یا فعال/غیرفعال کردن دسته‌بندی
router.patch(
  '/categories/:id',
  asyncHandler(async (req, res) => {
    const allowed = ['name', 'isActive'];
    const updates = {};
    for (const key of allowed) if (req.body[key] !== undefined) updates[key] = req.body[key];
    if (updates.name) updates.name = updates.name.trim();

    const category = await Category.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true });
    if (!category) return res.status(404).json({ ok: false, message: 'دسته‌بندی یافت نشد' });
    res.json({ ok: true, category });
  })
);

// DELETE /api/admin/categories/:id
router.delete(
  '/categories/:id',
  asyncHandler(async (req, res) => {
    const category = await Category.findById(req.params.id);
    if (!category) return res.status(404).json({ ok: false, message: 'دسته‌بندی یافت نشد' });
    await category.deleteOne();
    res.json({ ok: true });
  })
);

/* -------------------------------- تسک‌ها -------------------------------- */

// GET /api/admin/tasks?search=عنوان
router.get(
  '/tasks',
  asyncHandler(async (req, res) => {
    const filter = {};
    if (req.query.search && req.query.search.trim()) {
      filter.title = new RegExp(req.query.search.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    }
    const { page, limit, skip } = getPagination(req);
    const [tasks, total] = await Promise.all([
      Task.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
      Task.countDocuments(filter),
    ]);
    res.json({ ok: true, tasks, page, totalPages: Math.max(Math.ceil(total / limit), 1), total });
  })
);

// POST /api/admin/tasks — دکمه «+ تسک جدید»
router.post(
  '/tasks',
  validateBody({ title: 'string', category: 'string', price: 'number', requiredCount: 'number' }),
  asyncHandler(async (req, res) => {
    const task = await Task.create(req.body);
    res.status(201).json({ ok: true, task });
  })
);

// PATCH /api/admin/tasks/:id — ویرایش تسک یا تغییر تعداد مورد نیاز (+/-)
router.patch(
  '/tasks/:id',
  asyncHandler(async (req, res) => {
    const allowed = ['title', 'description', 'category', 'price', 'requiredCount', 'expiresAt', 'isActive'];
    const updates = {};
    for (const key of allowed) if (req.body[key] !== undefined) updates[key] = req.body[key];

    const task = await Task.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true });
    if (!task) return res.status(404).json({ ok: false, message: 'تسک یافت نشد' });
    res.json({ ok: true, task });
  })
);

// DELETE /api/admin/tasks/:id — حذف کامل تسک به همراه انجام‌تسک‌های مرتبط با آن
router.delete(
  '/tasks/:id',
  asyncHandler(async (req, res) => {
    const task = await Task.findById(req.params.id);
    if (!task) return res.status(404).json({ ok: false, message: 'تسک یافت نشد' });

    await Submission.deleteMany({ task: task._id });
    await task.deleteOne();

    res.json({ ok: true });
  })
);

/* ---------------------- درخواست‌های تسک کاربران (بودجه کیف‌پول) --------------------- */

// GET /api/admin/task-requests?status=pending — تب مجزای «درخواست‌های تسک» در پنل ادمین
router.get(
  '/task-requests',
  asyncHandler(async (req, res) => {
    const { status } = req.query;
    const filter = { createdBy: { $ne: null } };
    if (status && ['pending', 'approved', 'rejected'].includes(status)) filter.status = status;

    const { page, limit, skip } = getPagination(req);
    const [taskRequests, total] = await Promise.all([
      Task.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .populate('createdBy', 'fullname username walletBalance')
        .lean(),
      Task.countDocuments(filter),
    ]);
    res.json({ ok: true, taskRequests, page, totalPages: Math.max(Math.ceil(total / limit), 1), total });
  })
);

// PATCH /api/admin/task-requests/:id — تایید/رد درخواست تسک کاربر
// نکته امنیتی: بودجه فقط همین‌جا، در لحظه‌ی تایید، از کیف‌پول کاربر کسر می‌شود (نه در لحظه‌ی ثبت درخواست)
router.patch(
  '/task-requests/:id',
  validateBody({ status: 'string' }),
  asyncHandler(async (req, res) => {
    const { status } = req.body;
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ ok: false, message: 'وضعیت نامعتبر است' });
    }

    const task = await Task.findById(req.params.id);
    if (!task || !task.createdBy) {
      return res.status(404).json({ ok: false, message: 'درخواست تسک یافت نشد' });
    }
    if (task.status !== 'pending') {
      return res.status(400).json({ ok: false, message: 'این درخواست قبلاً بررسی شده است' });
    }

    if (status === 'approved') {
      const user = await User.findById(task.createdBy);
      if (!user) {
        return res.status(400).json({ ok: false, message: 'کاربر ثبت‌کننده‌ی این تسک دیگر وجود ندارد' });
      }
      if (user.walletBalance < task.budget) {
        return res.status(400).json({ ok: false, message: 'موجودی کیف پول کاربر برای این بودجه کافی نیست' });
      }
      user.walletBalance -= task.budget;
      await user.save();

      await Transaction.create({
        user: user._id,
        type: 'withdraw',
        amount: task.budget,
        status: 'approved',
        note: `کسر بودجه برای ثبت تسک «${task.title}»`,
      });

      task.isActive = true;
    }

    task.status = status;
    await task.save();
    res.json({ ok: true, task });
  })
);

/* ------------------------------ تراکنش‌ها ------------------------------- */

// GET /api/admin/transactions?status=در انتظار
router.get(
  '/transactions',
  asyncHandler(async (req, res) => {
    const { status } = req.query;
    const filter = status && status !== 'همه' ? { status } : {};
    const { page, limit, skip } = getPagination(req);
    const [transactions, total] = await Promise.all([
      Transaction.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).populate('user', 'fullname username').lean(),
      Transaction.countDocuments(filter),
    ]);
    // کاربر یک تراکنش ممکن است بعداً توسط ادمین حذف شده باشد؛ برای جلوگیری از user=null در فرانت‌اند
    const withFallback = transactions.map((t) => ({
      ...t,
      user: t.user || { fullname: 'کاربر حذف‌شده', username: '—' },
    }));
    res.json({ ok: true, transactions: withFallback, page, totalPages: Math.max(Math.ceil(total / limit), 1), total });
  })
);

// PATCH /api/admin/transactions/:id — دکمه‌های «تایید» / «رد»
// نکته امنیتی: موجودی کیف پول فقط همین‌جا و پس از تایید ادمین تغییر می‌کند
router.patch(
  '/transactions/:id',
  validateBody({ status: 'string' }),
  asyncHandler(async (req, res) => {
    const { status } = req.body;
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ ok: false, message: 'وضعیت نامعتبر است' });
    }

    const tx = await Transaction.findById(req.params.id);
    if (!tx) return res.status(404).json({ ok: false, message: 'تراکنش یافت نشد' });
    if (tx.status !== 'pending') {
      return res.status(400).json({ ok: false, message: 'این تراکنش قبلاً بررسی شده است' });
    }

    if (status === 'approved') {
      const user = await User.findById(tx.user);
      if (!user) {
        return res.status(400).json({ ok: false, message: 'کاربر این تراکنش دیگر وجود ندارد' });
      }
      if (tx.type === 'withdraw') {
        if (user.walletBalance < tx.amount) {
          return res.status(400).json({ ok: false, message: 'موجودی کاربر برای برداشت کافی نیست' });
        }
        user.walletBalance -= tx.amount;
      } else {
        user.walletBalance += tx.amount;
      }
      await user.save();
    }

    tx.status = status;
    await tx.save();
    res.json({ ok: true, transaction: tx });
  })
);

// PATCH /api/admin/submissions/:id — تایید/رد انجام تسک توسط کاربر و واریز خودکار به کیف پول
router.patch(
  '/submissions/:id',
  validateBody({ status: 'string' }),
  asyncHandler(async (req, res) => {
    const { status } = req.body;
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ ok: false, message: 'وضعیت نامعتبر است' });
    }

    const submission = await Submission.findById(req.params.id).populate('task');
    if (!submission) return res.status(404).json({ ok: false, message: 'رکورد یافت نشد' });
    if (submission.status !== 'pending') {
      return res.status(400).json({ ok: false, message: 'این مورد قبلاً بررسی شده است' });
    }

    if (status === 'approved') {
      const approvedCount = await Submission.countDocuments({ task: submission.task._id, status: 'approved' });
      if (approvedCount >= submission.task.requiredCount) {
        return res.status(400).json({ ok: false, message: 'ظرفیت این تسک قبلاً تکمیل شده؛ امکان تایید بیشتر نیست' });
      }
      await User.findByIdAndUpdate(submission.user, { $inc: { walletBalance: submission.task.price } });
    }
    submission.status = status;
    await submission.save();
    res.json({ ok: true, submission });
  })
);

module.exports = router;
