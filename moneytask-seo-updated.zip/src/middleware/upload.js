const multer = require('multer');
const path = require('path');
const fs = require('fs');

// اسکرین‌شات اثبات انجام تسک — داخل public/uploads ذخیره می‌شود تا از همان استاتیک‌سرور موجود قابل دسترسی باشد
const uploadDir = path.join(__dirname, '../../public/uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, `${unique}${path.extname(file.originalname).toLowerCase()}`);
  },
});

const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];

function fileFilter(req, file, cb) {
  if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
    return cb(new Error('فقط تصویر با فرمت jpg، png یا webp مجاز است'));
  }
  cb(null, true);
}

// حداکثر حجم مجاز اسکرین‌شات اثبات: ۵ مگابایت
const MAX_PROOF_SIZE = 5 * 1024 * 1024;

const uploadProof = multer({
  storage,
  fileFilter,
  limits: { fileSize: MAX_PROOF_SIZE },
});

/**
 * میان‌افزار آماده برای فیلد proof — خطاهای multer (حجم/فرمت) را به پاسخ JSON استاندارد پروژه تبدیل می‌کند
 */
function handleProofUpload(req, res, next) {
  uploadProof.single('proof')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ ok: false, message: 'حجم تصویر نباید بیشتر از ۵ مگابایت باشد' });
      }
      return res.status(400).json({ ok: false, message: 'خطا در آپلود تصویر' });
    }
    if (err) {
      return res.status(400).json({ ok: false, message: err.message || 'خطا در آپلود تصویر' });
    }
    next();
  });
}

module.exports = { uploadDir, handleProofUpload };
