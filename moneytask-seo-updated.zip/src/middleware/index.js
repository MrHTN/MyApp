/**
 * Wrapper برای هندلرهای async تا نیازی به try/catch تکراری نباشد
 */
const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const rateLimit = require('express-rate-limit');

/**
 * ساخت rate limiter با پاسخ JSON هماهنگ با فرمت استاندارد پروژه (ok/message)
 */
function createLimiter(windowMs, max, message) {
  return rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => res.status(429).json({ ok: false, message }),
  });
}

// جلوگیری از اسپم ثبت انجام‌تسک (آپلود فایل + رکورد دیتابیس)
const submitLimiter = createLimiter(60 * 60 * 1000, 20, 'تعداد درخواست‌های ثبت تسک شما در این ساعت زیاد بوده؛ کمی بعد دوباره امتحان کنید');
// جلوگیری از اسپم درخواست بازیابی رمز عبور
const passwordResetLimiter = createLimiter(60 * 60 * 1000, 5, 'تعداد درخواست‌های بازیابی رمز عبور شما زیاد بوده؛ کمی بعد دوباره امتحان کنید');
// جلوگیری از اسپم درخواست تراکنش (واریز/برداشت)
const transactionLimiter = createLimiter(60 * 60 * 1000, 10, 'تعداد درخواست‌های تراکنش شما در این ساعت زیاد بوده؛ کمی بعد دوباره امتحان کنید');

/**
 * فقط کاربر لاگین‌شده (session-based) اجازه عبور دارد
 */
function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ ok: false, message: 'ابتدا وارد حساب کاربری خود شوید' });
  }
  next();
}

/**
 * فقط ادمین اجازه عبور دارد — باید بعد از requireAuth استفاده شود
 */
function requireAdmin(req, res, next) {
  if (!req.session || req.session.role !== 'admin') {
    return res.status(403).json({ ok: false, message: 'دسترسی غیرمجاز' });
  }
  next();
}

/**
 * اعتبارسنجی سبک بدون وابستگی خارجی: بررسی وجود و نوع فیلدهای الزامی بدنه‌ی درخواست
 * rules نمونه: { username: 'string', password: 'string', price: 'number' }
 */
function validateBody(rules) {
  return (req, res, next) => {
    const errors = [];
    for (const [field, type] of Object.entries(rules)) {
      const value = req.body[field];
      if (value === undefined || value === null || value === '') {
        errors.push(`${field} الزامی است`);
        continue;
      }
      if (type === 'number' && typeof value !== 'number') errors.push(`${field} باید عدد باشد`);
      if (type === 'string' && typeof value !== 'string') errors.push(`${field} باید متن باشد`);
    }
    if (errors.length) return res.status(400).json({ ok: false, message: errors.join(' | ') });
    next();
  };
}

function notFound(req, res) {
  res.status(404).json({ ok: false, message: 'مسیر مورد نظر یافت نشد' });
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  console.error(err);
  // خطای duplicate key مونگو (مثلا username تکراری)
  if (err.code === 11000) {
    return res.status(409).json({ ok: false, message: 'این مقدار قبلاً استفاده شده است' });
  }
  if (err.name === 'ValidationError' || err.name === 'CastError') {
    return res.status(400).json({ ok: false, message: 'داده ارسالی نامعتبر است' });
  }
  res.status(err.status || 500).json({ ok: false, message: err.message || 'خطای داخلی سرور' });
}

module.exports = { asyncHandler, requireAuth, requireAdmin, validateBody, notFound, errorHandler, submitLimiter, transactionLimiter, passwordResetLimiter };
