/**
 * ابزار ارسال ایمیل بازیابی رمز عبور.
 *
 * برای فعال بودن ارسال واقعی ایمیل، متغیرهای زیر باید در .env تنظیم شوند:
 *   SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM
 *
 * اگر این متغیرها تنظیم نشده باشند (مثلاً در محیط توسعه)، به‌جای ارسال واقعی،
 * لینک بازیابی در لاگ سرور چاپ می‌شود تا توسعه/تست بدون سرویس SMTP واقعی ممکن باشد.
 */
let transporter = null;

function getTransporter() {
  if (transporter) return transporter;
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS } = process.env;
  if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS) return null;

  // نیازمند وابستگی nodemailer است (به package.json اضافه شده)
  const nodemailer = require('nodemailer');
  transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: Number(SMTP_PORT) === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  });
  return transporter;
}

async function sendResetPasswordEmail(toEmail, resetUrl) {
  const t = getTransporter();
  if (!t) {
    // حالت توسعه بدون SMTP: لینک را در لاگ سرور چاپ می‌کنیم
    console.log(`[dev-only] لینک بازیابی رمز عبور برای ${toEmail}: ${resetUrl}`);
    return;
  }
  await t.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: toEmail,
    subject: 'بازیابی رمز عبور مانی‌تسک',
    html: `
      <div dir="rtl" style="font-family: Tahoma, sans-serif;">
        <p>برای تنظیم رمز عبور جدید، روی لینک زیر کلیک کنید (اعتبار: ۳۰ دقیقه):</p>
        <p><a href="${resetUrl}">${resetUrl}</a></p>
        <p>اگر این درخواست را شما نداده‌اید، این ایمیل را نادیده بگیرید.</p>
      </div>`,
  });
}

module.exports = { sendResetPasswordEmail };
