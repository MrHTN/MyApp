const mongoose = require('mongoose');
const { Schema } = mongoose;

/**
 * User: هم کاربر عادی، هم ادمین (با فیلد role) — طبق صفحات login.html و admin-login.html
 */
const userSchema = new Schema(
  {
    fullname: { type: String, required: true, trim: true, maxlength: 100 },
    username: { type: String, required: true, unique: true, trim: true, lowercase: true, index: true },
    email: { type: String, trim: true, lowercase: true, default: null },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ['user', 'admin'], default: 'user' },
    phone: { type: String, trim: true, default: null },
    cardNumber: { type: String, trim: true, default: null },
    walletBalance: { type: Number, default: 0, min: 0 },
    status: { type: String, enum: ['active', 'blocked'], default: 'active' },
    // شناسه‌ی سشن فعال کاربر (برای اینکه ادمین بتونه سشنش رو بدون تغییر پسورد قطع کنه)
    currentSessionId: { type: String, default: null, select: false },
    // فیلدهای بازیابی رمز عبور — هش توکن (نه خود توکن) ذخیره می‌شود و پس از انقضا/استفاده باطل می‌شود
    resetPasswordTokenHash: { type: String, default: null, select: false },
    resetPasswordExpires: { type: Date, default: null, select: false },
  },
  { timestamps: true }
);

/**
 * Category: دسته‌بندی تسک‌ها — قابل مدیریت (ساخت/ویرایش/حذف) توسط ادمین
 */
const categorySchema = new Schema(
  {
    name: { type: String, required: true, trim: true, unique: true, maxlength: 50 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

/**
 * Task: طبق tasks.html / task-details.html / پنل ادمین
 */
const taskSchema = new Schema(
  {
    title: { type: String, required: true, trim: true, maxlength: 200 },
    description: { type: String, default: '', maxlength: 3000 },
    category: { type: String, required: true, trim: true }, // مثلا: تجربی / طراحی / سایر
    price: { type: Number, required: true, min: 0 },
    requiredCount: { type: Number, required: true, min: 1 }, // تعداد نفرات مورد نیاز
    expiresAt: { type: Date, default: null },
    isActive: { type: Boolean, default: true },
    // تسک‌های ثبت‌شده توسط کاربر عادی (با بودجه‌ی کیف‌پول)؛ تسک‌های ادمین این فیلد را null دارند
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', default: null, index: true },
    // تسک‌های ادمین همیشه approved هستند؛ تسک‌های کاربر تا تایید/رد ادمین در حالت pending می‌مانند
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'approved' },
    // بودجه‌ی کل اعلامی کاربر (فقط برای تسک‌های ثبت‌شده توسط کاربر) — ۳۰٪ آن کارمزد سیستم و
    // مابقی تقسیم بر requiredCount می‌شود که همان price بالاست
    budget: { type: Number, default: null },
  },
  { timestamps: true }
);

/**
 * Submission: وقتی کاربر دکمه «انجام تسک» را می‌زند یک رکورد اینجا ساخته می‌شود.
 * پیشرفت تسک (۶/۱۰) از شمارش submissionهای approved به‌دست می‌آید.
 */
const submissionSchema = new Schema(
  {
    task: { type: Schema.Types.ObjectId, ref: 'Task', required: true, index: true },
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    // مسیر تصویر اثبات انجام تسک (آپلود اجباری) — نسبت به public، مثلاً /uploads/xxx.jpg
    proofImage: { type: String, required: true },
  },
  { timestamps: true }
);
// هر کاربر فقط یک بار می‌تواند یک تسک را ثبت کند — اما این محدودیت فقط روی ارسال‌های
// فعال (در انتظار/تایید‌شده) اعمال می‌شود؛ اگر ارسال قبلی رد شده باشد، امکان ارسال مجدد وجود دارد
submissionSchema.index({ task: 1, user: 1 }, { unique: true, partialFilterExpression: { status: { $ne: 'rejected' } } });

/**
 * Transaction: واریز/برداشت کیف پول — طبق profile.html و تب تراکنش‌های ادمین
 */
const transactionSchema = new Schema(
  {
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    type: { type: String, enum: ['deposit', 'withdraw'], required: true },
    amount: { type: Number, required: true, min: 1 },
    status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
    note: { type: String, default: '' },
    // برداشت: شماره کارت مقصد که کاربر وارد می‌کند
    cardNumber: { type: String, trim: true, default: null },
    // واریز: نام واریزکننده و زمان واریز که کاربر بعد از واریز به کارت مقصد وارد می‌کند
    depositorName: { type: String, trim: true, default: null },
    depositTime: { type: String, trim: true, default: null },
  },
  { timestamps: true }
);

module.exports = {
  User: mongoose.model('User', userSchema),
  Category: mongoose.model('Category', categorySchema),
  Task: mongoose.model('Task', taskSchema),
  Submission: mongoose.model('Submission', submissionSchema),
  Transaction: mongoose.model('Transaction', transactionSchema),
};
